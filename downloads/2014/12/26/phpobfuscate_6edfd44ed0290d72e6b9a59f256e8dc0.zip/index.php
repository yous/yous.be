<?php

////////////////////////
//          stage1         //
////////////////////////

$á=array(0);
$$a=~$á[0];
$a+=$$a*$$a;
$á[$a]=~$a*-1^$a;
$á[a]=~$á[$a]*-1;
$á[$a]*=$á[a]*$á[$a];
$á[$a]+=$á[$a]^4;
$á[â]=$á[$a]/$á[a];
$à=$_GET[flag];
$á[$a]*=$a+$a;
$á[$a]-=$á[a]^$á[â];
if(ord($à[$a^$a])-$a!=$á[$a])exit("wrong");
$á[$a]-=$á[â]-$á[a];
if((ord($à[$a])-$á[a]!=$á[$a]-$a))exit("wrong");
$á[sqrt($á[a])] = round(sqrt($á[a]*ord($á)))*$á[a];
if($á[$a]-$a != ord($à[$á[a]-$a]))exit("wrong");
$á[round(sqrt($á[a]*ord($á)))*$á[a]] = sqrt($á[a]);
if((ord($à[pow($á[round(sqrt($á[a]*ord($á)))*$á[a]],$á[round(sqrt($á[a]*ord($á)))*$á[a]])])+$a) != $á[$a+$a]*(($á[a]*($a+$a)+$a)/($a+$á[a]+$a))) exit("wrong");
$á[$$a]=ord($à[$$a])-$á[â]+$a;
if(chr($á[$$a]+sqrt($á[$$a])-$a) != $à[$á[$a]-$á[$$a]])exit("wrong");


$flag_array = array(
    7,
    111,
    95,			/*
    114,			*        this is stage2 of challenge.
    117,			*          i think this stage is easy,
    98,			*  but you should read code deliberately
    105,			*     i hope you enjoy ctf and have fun.
    121,			*               from your friend
    97,			*                     rubiya
    95,			*/
    100,
    060
);
for($i=$a;$i<count($flag_array);$i++){ $flag_array[$i] = chr($flag_array[$i]); }
    for($count=5;$count<sqrt($á[$$a]);$count++){
        if($_GET[flag][$count].$_GET[fIag][$count-$i] != $flag_array[$count-$i].$_GET[fIag][$count-$i+1]) exit("wrong");
    }
    $flag_len = strlen($_GET[flag]);
    $length_chk = 1;
    while($flag_len > 1) $length_chk += $flag_len -= 1;
    if(($length_chk < 110) || ($length_chk > 130))exit("wrong");
    $stage3 = substr($_GET[flag],-7);
    $stage3_1 = substr($stage3,0,6);
    $stage3_2 = substr($stage3,1,6);
    $tmp = "stage3_";
    for($i=0;$i<6;$i++){
        $tmp .= ord($stage3_1[$i]) + ord($stage3_2[$i]);
    }
    if($tmp != "stage3_143193195211162158")exit("wrong");
    echo "You did it!<br>Flag is {<strong>" . $_GET[flag] . "</strong>}";

?>